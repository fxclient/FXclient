# Experimental Territorial.io opening presets

35 presets: Army, Expansion, Economy, Balanced, Long-term for target cycles 2–8.

**These files use a PROPOSED interchange format, not an established FX Client import format.** The coding agent should implement import of this schema or migrate it to the actual format after inspecting the target branch.

A `targetCycle` is the beginning of that cycle, so the last action must occur earlier. `cycle` and `tickInCycle` are one-based. `value` is percent of troops at send time.

**Critical:** numbers are illustrative experimental baselines; do not advertise them as optimal strategies. They have not been simulated with exact Territorial.io neutral-land expansion.

`long_term` optimizes conceptually for `evaluationCycle = targetCycle + 3`, but values are likewise unverified.
